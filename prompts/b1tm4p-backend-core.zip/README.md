# B1tm4p backend core

## Run

```bash
cp .env.example .env
# edit SMTP/admin values
mkdir -p data
docker compose up --build
```

Backend: `http://localhost:8080`; placeholder frontend: `http://localhost`.
The backend creates the four database paths under the named `/data` volume. `users.db` and `tags.db` are migrated by `migrate.js`; content/reports databases are optional until the content service creates them.

`better-sqlite3` is synchronous. The four SQLite files are never ATTACHed or cross-file joined.

## Authentication notes

- Session cookie: `b1tm4p_sid`, HttpOnly, SameSite=Lax, 30 days.
- Session token is a random 32-byte hex value; only its SHA-256 hash is stored.
- `app.set('trust proxy', true)` is enabled so Express can use proxy-provided client IP information. In production, only place the backend behind trusted proxies; `X-Forwarded-For` is therefore treated as proxy-controlled metadata.
- Passwords use bcrypt cost 10.
- SMTP failure does not expose credentials/tokens in API responses.

## Avatar integration checks

Set a valid authenticated cookie in `$COOKIE` after logging in.

### Inspect current account
```bash
curl -i -b "b1tm4p_sid=$COOKIE" http://localhost:8080/api/v1/me
```

### Switch to initials/circle
```bash
curl -i -X PATCH http://localhost:8080/api/v1/account/avatar \
  -H 'Content-Type: application/json' -b "b1tm4p_sid=$COOKIE" \
  -d '{"avatar_type":"initials","avatar_value":"AB","avatar_shape":"circle","avatar_color":"#FF7A00"}'
```

### Upload an image
```bash
curl -i -X POST http://localhost:8080/api/v1/account/avatar/upload \
  -b "b1tm4p_sid=$COOKIE" -F avatar=@./avatar.png
```
The server converts accepted JPEG/PNG/WebP/GIF input to 256x256 WebP and removes the previous image avatar when replaced.

### Non-staff square-avatar rejection
For a normal `user` or `support` account:
```bash
curl -i -X PATCH http://localhost:8080/api/v1/account/avatar \
  -H 'Content-Type: application/json' -b "b1tm4p_sid=$COOKIE" \
  -d '{"avatar_type":"initials","avatar_value":"AB","avatar_shape":"square","avatar_color":"#FF7A00"}'
```
Expected response: HTTP 403 and `{"error":"square avatars reserved for staff"}`.
The route re-reads the user's role from `users.db` for this check rather than trusting the session's cached role.

### Staff square-avatar success
Use a manager/admin cookie:
```bash
curl -i -X PATCH http://localhost:8080/api/v1/account/avatar \
  -H 'Content-Type: application/json' -b "b1tm4p_sid=$STAFF_COOKIE" \
  -d '{"avatar_type":"initials","avatar_value":"AD","avatar_shape":"square","avatar_color":"#FF7A00"}'
```

## Tag deletion policy

Deleting a master tag with child tags returns `409 {"error":"master_has_tags"}` unless `?force=true` is supplied. Force deletion cascades the child rows in `tags`. No content database is currently joined because posts/content belong to the next service.

## SMTP

Set `SMTP_USER`, `SMTP_PASS`, and `SMTP_FROM` for real delivery. `PUBLIC_BASE_URL` controls generated links. Password-reset and login-link request responses are intentionally generic.
