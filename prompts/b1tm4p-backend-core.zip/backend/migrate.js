const fs=require('fs');const path=require('path');const Database=require('better-sqlite3');
const dir='/data/db';fs.mkdirSync(dir,{recursive:true});
for(const [file,schema] of [['users.db','schema_users.sql'],['tags.db','schema_tags.sql']]){const db=new Database(path.join(dir,file));db.pragma('journal_mode=WAL');db.pragma('foreign_keys=ON');db.exec(fs.readFileSync(path.join(__dirname,'db',schema),'utf8'));db.close();}
