# B1tm4p Frontend Notes

## Contract source

The frontend was built against the API contract supplied in the conversation. It is treated as read-only ground truth.

## Endpoints actually called by frontend code

| Method | Path | Contract status |
|---|---|---|
| POST | `/api/v1/auth/login` | Documented |
| POST | `/api/v1/auth/register` | Documented |
| GET | `/api/v1/auth/verify?token=...` | Documented |
| POST | `/api/v1/auth/logout` | Documented |
| POST | `/api/v1/auth/password-reset-request` | Documented |
| POST | `/api/v1/auth/password-reset` | Documented |
| GET | `/api/v1/me` | Documented |
| PATCH | `/api/v1/account` | Documented |
| PATCH | `/api/v1/account/password` | Documented |
| PATCH | `/api/v1/account/avatar` | Documented |
| POST | `/api/v1/account/avatar/upload` | Documented |
| GET | `/api/v1/tags/master` | Documented |
| GET | `/api/v1/tags/master/:slug` | Documented |
| GET | `/api/v1/tags?master_slug=...` | Documented |
| POST | `/api/v1/tag-requests` | Documented |
| GET | `/api/v1/tag-requests?status=pending` | Documented for manager/admin |
| POST | `/api/v1/tag-requests/:id/approve` | Documented |
| POST | `/api/v1/tag-requests/:id/reject` | Documented |
| POST | `/api/v1/tags/master/:id/header` | Documented |

## Explicit contract gaps / assumptions

1. **Posts/feed**
   - The UI requirements expect a working `GET /api/v1/posts` with filters such as `search` and master/tag filters, plus a documented post response containing author/avatar data, body data, like state/count, and reply count.
   - The supplied contract explicitly says any request under `/api/v1/posts` currently returns `501 not_implemented_yet`.
   - Therefore production code does **not** fabricate feed data and does **not** call an undocumented POST endpoint for creating posts.
   - `fetchPosts()` is a deliberate TODO/contract-gap stub.

2. **Post detail and replies**
   - The UI requirements need a post-detail endpoint and a reply-tree endpoint/response shape, but no such endpoint is documented.
   - `/api/v1/posts/:id` is therefore not invented or called.
   - The post page displays a clear contract-gap message.

3. **Likes**
   - The UI requirements need a like-toggle endpoint, but the supplied contract documents none.
   - No guessed like endpoint is called.

4. **Reports**
   - The UI requirements need report creation and manager/admin pending-report listing/actions.
   - The supplied contract only says `/api/v1/reports` returns `501 not_implemented_yet`; no method-specific schemas are documented.
   - The report form is present but deliberately does not submit fabricated API requests.
   - Pending reports are likewise clearly marked unavailable.

5. **Own tag-request history**
   - The supplied contract documents `GET /api/v1/tag-requests?status=...` only for manager/admin.
   - It does not document a support-user endpoint for “my requests”.
   - The account UI therefore flags that section as unavailable rather than guessing an endpoint.

6. **New-post multipart creation**
   - No method/path/request shape is documented for creating posts.
   - The composer UI is real, but submission reports the contract gap rather than sending an invented request.

7. **Dynamic upload limit**
   - `nginx.conf` uses `50m`, matching the supplied example/default `UPLOAD_MAX_MB=50`.
   - Nginx cannot interpolate `.env` directly. If Prompt 1's deployment changes `UPLOAD_MAX_MB`, this value must be changed in nginx configuration (or templated at container startup).

8. **Legal route**
   - The header/footer link `/legal` is a normal static route handled by the SPA fallback. The supplied API contract does not define a legal/cookies API or page content, so this frontend currently only routes there through the SPA fallback.
   - No backend endpoint is invented for legal content.

## Auth and avatar checks

- Every API `fetch` uses `credentials: "include"`.
- 401 errors from protected API calls are surfaced and, where the UI can continue meaningfully, linked/redirected to `/login?return_to=...`.
- Avatar image vs initials, circle vs square, color luminance, and staff-only square behavior are reflected in the UI. The backend remains authoritative and re-checks role.
- The login notice is keyed by user ID and only created after a successful login event; it is not displayed on every page load.

## Theme

The theme is selected in an inline `<head>` script before the main stylesheet loads, using `localStorage` and the system preference as fallback. The accent remains `#FF7A00` in both themes.
