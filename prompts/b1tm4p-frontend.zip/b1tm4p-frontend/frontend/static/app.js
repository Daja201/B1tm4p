
(() => {
  "use strict";

  const API = "/api/v1";
  const state = {
    me: null,
    masters: [],
    currentMaster: null,
    currentTags: [],
    feedOffset: 0,
    feedLimit: 20,
    feedTotal: 0,
    feedLoading: false,
    search: "",
    masterSlug: "",
    feedMode: "home"
  };

  const $ = (s, root = document) => root.querySelector(s);
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[c]));
  const now = () => Math.floor(Date.now() / 1000);

  function apiErrorMessage(data, status) {
    if (data?.error) return data.error;
    return status >= 500 ? "server_error" : "request_failed";
  }

  async function api(path, options = {}) {
    const opts = {...options, credentials: "include"};
    opts.headers = {...(options.headers || {})};
    if (opts.body && !(opts.body instanceof FormData) && typeof opts.body !== "string") {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(opts.body);
    }
    const res = await fetch(API + path, opts);
    let data = null;
    try { data = await res.json(); } catch {}
    if (!res.ok) {
      const err = new Error(apiErrorMessage(data, res.status));
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  function showToast(message, kind = "") {
    $("#toast-root").innerHTML = `<div class="toast ${kind}">${esc(message)}</div>`;
    setTimeout(() => $("#toast-root").innerHTML = "", 3500);
  }

  function setTheme(theme) {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem("b1tm4p_theme", theme);
    const checkbox = $("#theme-switch");
    if (checkbox) checkbox.checked = theme === "light";
  }

  function luminance(hex) {
    const m = /^#([0-9a-f]{6})$/i.exec(hex || "");
    if (!m) return 1;
    const rgb = [0,2,4].map(i => parseInt(m[1].slice(i,i+2),16)/255);
    const lin = rgb.map(c => c <= .03928 ? c/12.92 : Math.pow((c+.055)/1.055,2.4));
    return .2126*lin[0] + .7152*lin[1] + .0722*lin[2];
  }

  function avatarHTML(user, cls = "") {
    if (!user) return "";
    const shape = user.avatar_shape === "square" ? "square" : "circle";
    if (user.avatar_type === "image") {
      return `<div class="avatar ${shape} ${cls}"><img src="${esc(user.avatar_value)}" alt="${esc(user.username || "avatar")}"></div>`;
    }
    const bg = /^#[0-9A-Fa-f]{6}$/.test(user.avatar_color || "") ? user.avatar_color : "#FF7A00";
    const fg = luminance(bg) > .52 ? "#000" : "#fff";
    return `<div class="avatar ${shape} ${cls}" style="background:${esc(bg)};color:${fg}">${esc(user.avatar_value || "US")}</div>`;
  }

  function relativeTime(ts) {
    const diff = Math.max(0, now() - Number(ts || 0));
    if (diff < 60) return `${diff}s ago`;
    const m = Math.floor(diff/60);
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m/60);
    if (h < 24) return `${h}h ago`;
    const d = Math.floor(h/24);
    if (d < 30) return `${d}d ago`;
    const mo = Math.floor(d/30);
    if (mo < 12) return `${mo}mo ago`;
    return `${Math.floor(mo/12)}y ago`;
  }

  function route() {
    const p = location.pathname;
    if (p === "/") return renderHome();
    if (p.startsWith("/tag/")) return renderTag(decodeURIComponent(p.slice(5)));
    if (p.startsWith("/post/")) return renderPost(p.slice(6));
    if (p === "/reports") return renderReports();
    if (p === "/account") return renderAccount();
    if (p === "/login") return renderLogin();
    if (p === "/register") return renderRegister();
    if (p === "/verify-email") return renderVerify();
    if (p === "/reset-password") return renderResetPassword();
    if (p === "/legal") return renderLegal();
    if (p === "/search") return renderSearch();
    return renderNotFound();
  }

  function navigate(url) {
    history.pushState({}, "", url);
    route();
    window.scrollTo(0,0);
  }

  function renderHeader() {
    const appPath = location.pathname;
    const reportContext = appPath.startsWith("/post/") ? `?content_type=post&content_id=${encodeURIComponent(appPath.slice(6))}` : "";
    const brand = state.currentMaster
      ? `<span>${esc(state.currentMaster.name)}</span>`
      : `<span>B1tm4p</span>`;

    $("#site-header").className = "site-header";
    $("#site-header").innerHTML = `
      <div class="header-inner">
        <a class="icon-btn" href="/" aria-label="Home">⌂</a>
        <button class="icon-btn" id="search-btn" aria-label="Search">⌕</button>
        ${state.searchOpen ? `
          <form class="search-inline" id="search-form">
            <input id="search-input" value="${esc(state.search || "")}" placeholder="Search posts" aria-label="Search posts">
          </form>` : ""}
        <a class="brand" href="/">${brand}</a>
        <a class="icon-btn" href="/reports${reportContext}" aria-label="Report">⚑</a>
        <div class="header-spacer"></div>
        ${state.me ? `
          <div class="account-wrap">
            <button class="avatar-button" id="avatar-menu-btn" aria-label="Account">
              ${avatarHTML(state.me)}
            </button>
            ${state.accountMenu ? `
              <div class="account-menu">
                <a href="/account">Account</a>
                ${["manager","admin"].includes(state.me.role) ? `<a href="/account#admin">Admin Console</a>` : ""}
                <button id="logout-btn">Log out</button>
              </div>` : ""}
          </div>` : `<a href="/login">Log in</a>`}
      </div>`;

    $("#search-btn").onclick = () => {
      state.searchOpen = !state.searchOpen;
      renderHeader();
      if (state.searchOpen) $("#search-input")?.focus();
    };
    $("#search-form")?.addEventListener("submit", e => {
      e.preventDefault();
      const q = $("#search-input").value.trim();
      navigate(`/search?q=${encodeURIComponent(q)}`);
    });
    $("#avatar-menu-btn")?.addEventListener("click", () => {
      state.accountMenu = !state.accountMenu;
      renderHeader();
    });
    $("#logout-btn")?.addEventListener("click", async () => {
      try { await api("/auth/logout", {method:"POST"}); }
      catch {}
      state.me = null; state.accountMenu = false;
      navigate("/login");
    });
  }

  function renderFooter() {
    $("#site-footer").className = "footer";
    $("#site-footer").innerHTML = `
      <div class="footer-inner">
        <span>B1tm4p</span>
        <span><a href="/legal">Legal / Cookies</a> · © ${new Date().getFullYear()} B1tm4p</span>
      </div>`;
  }

  function loading() { return `<div class="loading"><div class="spinner" aria-label="Loading"></div></div>`; }
  function errorBox(e) {
    if (e?.status === 401) {
      const ret = encodeURIComponent(location.pathname + location.search);
      return `<div class="notice error">Session required. <a href="/login?return_to=${ret}">Log in</a></div>`;
    }
    return `<div class="notice error">Could not load this section: ${esc(e?.message || "request_failed")}</div>`;
  }

  async function loadMe() {
    try { state.me = await api("/me"); }
    catch (e) { if (e.status === 401) state.me = null; else throw e; }
  }

  async function loadMasters() {
    const d = await api("/tags/master?limit=100&offset=0");
    state.masters = d.items || [];
  }

  function chipsHTML(items, activeSlug = "") {
    return `<div class="chips">
      ${items.map(x => `<a class="chip ${x.slug === activeSlug ? "active":""}" href="/tag/${encodeURIComponent(x.slug)}">${esc(x.name)}</a>`).join("")}
    </div>`;
  }

  /*
   * TODO(API contract gap): GET /api/v1/posts is reserved and documented only
   * as 501 not_implemented_yet. The requested feed needs a documented response
   * schema and filter names (master_slug, tag_id, search, liked state, etc.).
   * No mock content is used here.
   */
  async function fetchPosts() {
    throw Object.assign(new Error("posts_not_documented"), {status: 501});
  }

  function feedUnavailable() {
    return `<div class="card notice">
      <strong>Content feed unavailable.</strong>
      <p>The supplied API contract reserves <code>/api/v1/posts</code> but does not document a working GET endpoint or response schema yet. This frontend intentionally does not fabricate data.</p>
      <p class="muted">See FRONTEND_NOTES.md for the exact contract gap.</p>
    </div>`;
  }

  function postHTML(post) {
    const author = post.author || {
      username: post.username, avatar_type: post.avatar_type, avatar_value: post.avatar_value,
      avatar_shape: post.avatar_shape, avatar_color: post.avatar_color
    };
    let body = "";
    if (post.body_type === "image") body = `<img class="media" src="${esc(post.body_value || post.media_url)}" alt="">`;
    else if (post.body_type === "sound") body = `<audio controls src="${esc(post.body_value || post.media_url)}"></audio>`;
    else if (post.body_type === "video") body = `<video class="media" controls src="${esc(post.body_value || post.media_url)}"></video>`;
    else body = `<div class="body-text">${esc(post.body || post.body_value || "")}</div>`;

    return `<article class="feed-item" data-post-id="${esc(post.id)}">
      <aside class="feed-author">
        ${avatarHTML(author)}
        <a class="author-name" href="/search?q=${encodeURIComponent(author.username || "")}">${esc(author.username || "unknown")}</a>
        <span class="timestamp">${relativeTime(post.created_at)}</span>
        <div class="row">
          <button class="like ${post.liked ? "liked":""}" data-like-post="${esc(post.id)}" title="Like">
            <span class="heart">${post.liked ? "♥" : "♡"}</span> <span class="like-count">${Number(post.like_count || 0)}</span>
          </button>
        </div>
      </aside>
      <div class="content-body">
        ${post.header_title ? `<div class="header-title">${esc(post.header_title)}</div>` : ""}
        ${body}
        <div class="content-actions">
          <a class="thread-link" href="/post/${encodeURIComponent(post.id)}">View thread · ${Number(post.reply_count || 0)} replies</a>
        </div>
      </div>
    </article>`;
  }

  async function loadFeed(container, params = {}) {
    container.innerHTML = loading();
    try {
      await fetchPosts();
    } catch (e) {
      if (e.status === 501) container.innerHTML = feedUnavailable();
      else container.innerHTML = errorBox(e);
    }
  }

  function composerHTML() {
    if (!state.me) return "";
    return `<section class="card" id="composer">
      <h2>New post</h2>
      <form id="new-post-form" class="form-grid">
        <label>Master tag
          <select id="post-master" required><option value="">Select…</option>
            ${state.masters.map(m => `<option value="${m.id}">${esc(m.name)}</option>`).join("")}
          </select>
        </label>
        <label>Tag
          <select id="post-tag" required disabled><option value="">Select master first</option></select>
        </label>
        <label>Header title <input id="post-title" maxlength="200"></label>
        <label>Body type
          <select id="post-body-type">
            <option value="text">Text</option><option value="image">Image</option>
            <option value="sound">Sound</option><option value="video">Video</option>
          </select>
        </label>
        <div id="post-body-input"></div>
        <button class="primary" type="submit">Publish</button>
        <div id="composer-status"></div>
      </form>
    </section>`;
  }

  async function wireComposer() {
    const form = $("#new-post-form");
    if (!form) return;
    const type = $("#post-body-type"), input = $("#post-body-input");
    const updateInput = () => {
      const t = type.value;
      input.innerHTML = t === "text"
        ? `<label>Body <textarea id="post-body" required></textarea></label>`
        : `<label>File <input id="post-file" type="file" required accept="${t === "image" ? "image/jpeg,image/png,image/webp,image/gif" : t === "sound" ? "audio/*" : "video/*"}"></label>`;
    };
    updateInput();
    type.onchange = updateInput;

    $("#post-master").onchange = async e => {
      const select = $("#post-tag");
      select.disabled = true;
      select.innerHTML = `<option>Loading…</option>`;
      try {
        const d = await api(`/tags?master_slug=${encodeURIComponent(
          state.masters.find(m => String(m.id) === e.target.value)?.slug || ""
        )}&limit=100&offset=0`);
        select.innerHTML = d.items.map(t => `<option value="${t.id}">${esc(t.name)}</option>`).join("");
        select.disabled = d.items.length === 0;
      } catch (err) {
        select.innerHTML = `<option>${esc(err.message)}</option>`;
      }
    };

    form.onsubmit = async e => {
      e.preventDefault();
      /*
       * TODO(API contract gap): The requested multipart post-creation endpoint
       * is not documented. The contract only says /api/v1/posts returns 501.
       * Do not guess POST /posts request fields.
       */
      $("#composer-status").innerHTML = `<span class="error">Post creation endpoint is not documented in the supplied API contract.</span>`;
    };
  }

  async function renderHome() {
    state.currentMaster = null; state.feedMode = "home"; state.search = "";
    renderHeader(); renderFooter();
    const app = $("#app"); app.innerHTML = loading();
    try {
      await Promise.all([loadMe(), loadMasters()]);
      renderHeader();
      app.innerHTML = `
        <h1 class="page-title">Home</h1>
        ${chipsHTML(state.masters)}
        ${composerHTML()}
        <section id="feed" class="feed">${loading()}</section>`;
      await wireComposer();
      await loadFeed($("#feed"));
    } catch (e) { app.innerHTML = errorBox(e); }
  }

  async function renderTag(slug) {
    state.feedMode = "tag"; state.masterSlug = slug;
    renderHeader(); renderFooter();
    const app = $("#app"); app.innerHTML = loading();
    try {
      await Promise.all([loadMe(), loadMasters()]);
      const d = await api(`/tags/master/${encodeURIComponent(slug)}`);
      state.currentMaster = d;
      state.currentTags = d.tags || [];
      renderHeader();
      app.innerHTML = `
        ${d.header_image_path
          ? `<img class="banner" src="${esc(d.header_image_path)}" alt="${esc(d.name)} header">`
          : `<div class="banner-placeholder">No header image</div>`}
        <div class="row" style="justify-content:space-between;margin-top:16px">
          <div><h1 class="page-title">${esc(d.name)}</h1><p class="muted">${esc(d.description || "")}</p></div>
          ${["manager","admin"].includes(state.me?.role) ? `<label class="primary" style="cursor:pointer">Upload header <input id="header-upload" type="file" accept="image/*" hidden></label>` : ""}
        </div>
        ${chipsHTML(state.currentTags)}
        ${composerHTML()}
        <section id="feed" class="feed">${loading()}</section>`;
      $("#header-upload")?.addEventListener("change", uploadHeader);
      await wireComposer();
      await loadFeed($("#feed"), {master_slug: slug});
    } catch (e) { app.innerHTML = errorBox(e); }
  }

  async function uploadHeader(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const fd = new FormData(); fd.append("header", file);
    try {
      await api(`/tags/master/${encodeURIComponent(state.currentMaster.id)}/header`, {method:"POST", body:fd});
      await renderTag(state.currentMaster.slug);
    } catch (err) {
      if (err.status === 401) navigate(`/login?return_to=${encodeURIComponent(location.pathname)}`);
      else showToast(err.message, "error");
    }
  }

  async function renderPost(id) {
    state.currentMaster = null; renderHeader(); renderFooter();
    const app = $("#app");
    /*
     * TODO(API contract gap): No GET /api/v1/posts/:id or reply endpoint is
     * documented. The supplied contract explicitly reserves /api/v1/posts.
     */
    app.innerHTML = `<div class="card notice">
      <h1 class="page-title">Post ${esc(id)}</h1>
      <p>Thread rendering is ready in the UI architecture, but the supplied contract does not document a working post-detail/replies endpoint or response shape.</p>
      <p class="muted">No mock thread data is used.</p>
    </div>`;
  }

  async function renderReports() {
    state.currentMaster = null; renderHeader(); renderFooter();
    const app = $("#app"); app.innerHTML = loading();
    try {
      await loadMe();
      if (!state.me) {
        app.innerHTML = `<div class="auth-page"><div class="card">${errorBox({status:401})}</div></div>`;
        return;
      }
      const q = new URLSearchParams(location.search);
      app.innerHTML = `
        <h1 class="page-title">Reports</h1>
        <section class="card">
          <h2>Submit a report</h2>
          <p class="muted">The report endpoint is reserved by the current contract and is not implemented yet.</p>
          <form id="report-form" class="form-grid">
            <label>Content type <input id="report-type" value="${esc(q.get("content_type") || "")}" placeholder="post"></label>
            <label>Content ID <input id="report-id" value="${esc(q.get("content_id") || "")}"></label>
            <label>Reason <textarea id="report-reason" required></textarea></label>
            <button class="primary">Submit report</button>
            <div id="report-status"></div>
          </form>
        </section>
        ${["manager","admin"].includes(state.me.role) ? `<section class="card"><h2>Pending reports</h2><p class="muted">TODO: the contract does not document a GET /api/v1/reports endpoint or response schema.</p></section>` : ""}`;
      $("#report-form").onsubmit = e => {
        e.preventDefault();
        $("#report-status").innerHTML = `<span class="error">Report submission endpoint is not documented in the supplied API contract.</span>`;
      };
    } catch (e) { app.innerHTML = errorBox(e); }
  }

  async function renderAccount() {
    state.currentMaster = null; renderHeader(); renderFooter();
    const app = $("#app"); app.innerHTML = loading();
    try {
      await loadMe();
      if (!state.me) { app.innerHTML = `<div class="auth-page"><div class="card">${errorBox({status:401})}</div></div>`; return; }
      const m = state.me;
      app.innerHTML = `
        <h1 class="page-title">Account</h1>
        <div class="two-col">
          <section class="card">
            <h2>Profile</h2>
            <form id="profile-form" class="form-grid">
              <label>Username <input id="username" value="${esc(m.username)}"></label>
              <label>Email <input id="email" type="email" value="${esc(m.email)}"></label>
              <button class="primary">Save profile</button>
              <div id="profile-status"></div>
            </form>
          </section>
          <section class="card">
            <h2>Avatar</h2>
            <div id="avatar-preview" class="profile-avatar-preview">${avatarHTML(m)}</div>
            <hr>
            <form id="avatar-form" class="form-grid">
              <label>Mode
                <select id="avatar-type"><option value="initials">Initials</option><option value="image">Image</option></select>
              </label>
              <div id="initials-controls">
                <label>Initials <input id="avatar-value" maxlength="2" value="${esc(m.avatar_value)}"></label>
                <label>Color <input id="avatar-color" type="color" value="${esc(m.avatar_color)}"></label>
                <label>Shape
                  <select id="avatar-shape" ${["manager","admin"].includes(m.role) ? "" : "disabled"}>
                    <option value="circle">Circle</option><option value="square">Square</option>
                  </select>
                </label>
                ${!["manager","admin"].includes(m.role) ? `<span class="muted">Square avatars are reserved for staff.</span>` : ""}
              </div>
              <div id="image-controls" hidden>
                <label>Image <input id="avatar-file" type="file" accept="image/jpeg,image/png,image/webp,image/gif"></label>
                <button type="button" id="upload-avatar">Upload image</button>
              </div>
              <button class="primary" id="save-avatar">Save avatar settings</button>
              <div id="avatar-status"></div>
            </form>
          </section>
        </div>
        <section class="card" style="margin-top:16px">
          <h2>Password</h2>
          <form id="password-form" class="form-grid">
            <label>Current password <input id="current-password" type="password" required></label>
            <label>New password <input id="new-password" type="password" required minlength="8"></label>
            <button class="primary">Change password</button>
            <div id="password-status"></div>
          </form>
        </section>
        ${["support","manager","admin"].includes(m.role) ? `
          <section class="card" style="margin-top:16px">
            <h2>Tag Requests</h2>
            <form id="tag-request-form" class="form-grid">
              <label>Request type <select id="request-type"><option value="master_tag">Master tag</option><option value="tag">Tag</option></select></label>
              <label>Proposed name <input id="proposed-name" required></label>
              <label>Parent master tag ID (tag only) <input id="parent-master-id" type="number"></label>
              <button class="primary">Submit request</button>
              <div id="tag-request-status"></div>
            </form>
            <div id="my-requests">${loading()}</div>
          </section>` : ""}
        ${["manager","admin"].includes(m.role) ? `
          <section class="card" style="margin-top:16px">
            <h2>Approvals</h2><div id="approvals">${loading()}</div>
          </section>` : ""}
        ${m.role === "admin" ? `<p><a href="/admin-raw">Admin Console</a></p>` : ""}`;
      wireAccount();
    } catch (e) { app.innerHTML = errorBox(e); }
  }

  function wireAccount() {
    $("#profile-form").onsubmit = async e => {
      e.preventDefault();
      const out = $("#profile-status"); out.textContent = "Saving…";
      try {
        state.me = await api("/account", {method:"PATCH", body:{username:$("#username").value, email:$("#email").value}});
        out.innerHTML = `<span class="success">Saved.</span>`; renderHeader();
      } catch (err) { out.innerHTML = `<span class="error">${esc(err.message)}</span>`; }
    };

    $("#avatar-type").onchange = e => {
      $("#initials-controls").hidden = e.target.value !== "initials";
      $("#image-controls").hidden = e.target.value !== "image";
      $("#save-avatar").hidden = e.target.value === "image";
    };
    $("#save-avatar").onclick = async e => {
      e.preventDefault();
      const out = $("#avatar-status");
      try {
        const shape = $("#avatar-shape").value;
        state.me = await api("/account/avatar", {method:"PATCH", body:{
          avatar_type:"initials",
          avatar_value:$("#avatar-value").value,
          avatar_shape:shape,
          avatar_color:$("#avatar-color").value
        }});
        out.innerHTML = `<span class="success">Avatar saved.</span>`;
        $("#avatar-preview").innerHTML = avatarHTML(state.me);
        renderHeader();
      } catch (err) { out.innerHTML = `<span class="error">${esc(err.message)}</span>`; }
    };
    $("#upload-avatar").onclick = async () => {
      const file = $("#avatar-file").files?.[0];
      if (!file) return;
      const fd = new FormData(); fd.append("avatar", file);
      try {
        state.me = await api("/account/avatar/upload", {method:"POST", body:fd});
        $("#avatar-status").innerHTML = `<span class="success">Image uploaded.</span>`;
        $("#avatar-preview").innerHTML = avatarHTML(state.me);
        renderHeader();
      } catch (err) { $("#avatar-status").innerHTML = `<span class="error">${esc(err.message)}</span>`; }
    };
    $("#password-form").onsubmit = async e => {
      e.preventDefault();
      const out = $("#password-status"); out.textContent = "Saving…";
      try {
        await api("/account/password", {method:"PATCH", body:{
          current_password:$("#current-password").value,
          new_password:$("#new-password").value
        }});
        out.innerHTML = `<span class="success">Password changed.</span>`;
        e.target.reset();
      } catch (err) { out.innerHTML = `<span class="error">${esc(err.message)}</span>`; }
    };

    $("#tag-request-form")?.addEventListener("submit", async e => {
      e.preventDefault();
      const body = {request_type:$("#request-type").value, proposed_name:$("#proposed-name").value};
      if (body.request_type === "tag") body.parent_master_tag_id = Number($("#parent-master-id").value);
      try {
        await api("/tag-requests", {method:"POST", body});
        $("#tag-request-status").innerHTML = `<span class="success">Request submitted.</span>`;
        loadMyRequests();
      } catch (err) { $("#tag-request-status").innerHTML = `<span class="error">${esc(err.message)}</span>`; }
    });
    loadMyRequests();
    loadApprovals();
  }

  async function loadMyRequests() {
    if (!$("#my-requests")) return;
    /*
     * TODO(API contract gap): There is no documented endpoint for a support
     * user to list their own requests. GET /tag-requests requires manager/admin.
     */
    $("#my-requests").innerHTML = `<p class="muted">Past-request list is unavailable: the contract documents only manager/admin GET /api/v1/tag-requests?status=….</p>`;
  }

  async function loadApprovals() {
    if (!$("#approvals")) return;
    try {
      const d = await api("/tag-requests?status=pending&limit=100&offset=0");
      $("#approvals").innerHTML = d.items?.length ? d.items.map(r => `
        <div class="card">
          <strong>${esc(r.proposed_name)}</strong> <span class="muted">#${r.id} · ${esc(r.request_type)}</span>
          <p>${r.parent_master_tag_id ? `Parent master #${r.parent_master_tag_id}` : ""}</p>
          <div class="row">
            <button data-approve="${r.id}">Approve</button>
            <button data-reject="${r.id}">Reject</button>
          </div>
        </div>`).join("") : `<div class="empty">No pending requests.</div>`;
      $("#approvals").querySelectorAll("[data-approve]").forEach(b => b.onclick = () => reviewRequest(b.dataset.approve, "approve"));
      $("#approvals").querySelectorAll("[data-reject]").forEach(b => b.onclick = () => reviewRequest(b.dataset.reject, "reject"));
    } catch (e) { $("#approvals").innerHTML = errorBox(e); }
  }

  async function reviewRequest(id, action) {
    try {
      await api(`/tag-requests/${encodeURIComponent(id)}/${action}`, {method:"POST", body:{}});
      loadApprovals();
    } catch (e) { showToast(e.message, "error"); }
  }

  function authLayout(title, body) {
    state.currentMaster = null; renderHeader(); renderFooter();
    $("#app").innerHTML = `<div class="auth-page"><div class="card"><h1 class="page-title">${title}</h1>${body}</div></div>`;
  }

  async function renderLogin() {
    authLayout("Log in", `
      <form id="login-form" class="form-grid">
        <label>Email <input id="email" type="email" required autocomplete="email"></label>
        <label>Password <input id="password" type="password" required autocomplete="current-password"></label>
        <button class="primary">Log in</button>
        <div id="login-status"></div>
      </form>
      <p><a href="/reset-password">Forgot password?</a></p>
      <p>New here? <a href="/register">Create an account</a></p>`);
    $("#login-form").onsubmit = async e => {
      e.preventDefault();
      const out = $("#login-status"); out.textContent = "Signing in…";
      try {
        const user = await api("/auth/login", {method:"POST", body:{email:$("#email").value,password:$("#password").value}});
        state.me = user;
        await postLoginNotices(user);
        const ret = new URLSearchParams(location.search).get("return_to") || "/";
        navigate(ret);
      } catch (err) {
        out.innerHTML = `<span class="error">${esc(err.message)}</span>`;
      }
    };
  }

  async function renderRegister() {
    authLayout("Register", `
      <form id="register-form" class="form-grid">
        <label>Email <input id="email" type="email" required></label>
        <label>Username <input id="username" required></label>
        <label>Password <input id="password" type="password" minlength="8" required></label>
        <button class="primary">Register</button>
        <div id="register-status"></div>
      </form>
      <p>Already registered? <a href="/login">Log in</a></p>`);
    $("#register-form").onsubmit = async e => {
      e.preventDefault();
      const out = $("#register-status"); out.textContent = "Creating account…";
      try {
        const d = await api("/auth/register", {method:"POST", body:{
          email:$("#email").value, username:$("#username").value, password:$("#password").value
        }});
        out.innerHTML = `<span class="success">Account created. Check your email to verify it.</span>`;
        e.target.reset();
      } catch (err) { out.innerHTML = `<span class="error">${esc(err.message)}</span>`; }
    };
  }

  async function renderVerify() {
    const token = new URLSearchParams(location.search).get("token") || "";
    authLayout("Verify email", `<div id="verify-status">${loading()}</div>`);
    try {
      await api(`/auth/verify?token=${encodeURIComponent(token)}`);
      $("#verify-status").innerHTML = `<p class="success">Email verified. <a href="/login">Log in</a>.</p>`;
    } catch (e) { $("#verify-status").innerHTML = errorBox(e); }
  }

  async function renderResetPassword() {
    const token = new URLSearchParams(location.search).get("token") || "";
    authLayout("Reset password", `
      <form id="reset-form" class="form-grid">
        <label>New password <input id="new-password" type="password" minlength="8" required></label>
        <button class="primary">Reset password</button>
        <div id="reset-status"></div>
      </form>
      <hr>
      <form id="reset-request-form" class="form-grid">
        <label>Request reset email <input id="reset-email" type="email" required></label>
        <button>Send reset email</button>
        <div id="request-status"></div>
      </form>`);
    $("#reset-form").onsubmit = async e => {
      e.preventDefault();
      try {
        await api("/auth/password-reset", {method:"POST", body:{token,new_password:$("#new-password").value}});
        $("#reset-status").innerHTML = `<span class="success">Password reset. <a href="/login">Log in</a>.</span>`;
      } catch (err) { $("#reset-status").innerHTML = `<span class="error">${esc(err.message)}</span>`; }
    };
    $("#reset-request-form").onsubmit = async e => {
      e.preventDefault();
      try {
        await api("/auth/password-reset-request", {method:"POST", body:{email:$("#reset-email").value}});
        $("#request-status").innerHTML = `<span class="success">If the account exists, a reset email was sent.</span>`;
      } catch (err) { $("#request-status").innerHTML = `<span class="error">${esc(err.message)}</span>`; }
    };
  }

  async function renderSearch() {
    state.currentMaster = null; state.search = new URLSearchParams(location.search).get("q") || "";
    renderHeader(); renderFooter();
    const app = $("#app");
    app.innerHTML = `<h1 class="page-title">Search</h1><p class="muted">Query: ${esc(state.search)}</p><section id="feed" class="feed">${loading()}</section>`;
    await loadFeed($("#feed"), {search:state.search});
  }

  function renderLegal() {
    state.currentMaster = null; renderHeader(); renderFooter();
    $("#app").innerHTML = `<div class="auth-page"><div class="card">
      <h1 class="page-title">Legal / Cookies</h1>
      <p>This frontend uses the essential B1tm4p session cookie for authentication. No optional analytics cookie is introduced by this frontend.</p>
      <p>User-submitted content remains the responsibility of the submitting user. The administrator/operator does not assume responsibility for user-submitted content.</p>
      <p><a href="/">Back to B1tm4p</a></p>
    </div></div>`;
  }

  function renderNotFound() {
    renderHeader(); renderFooter();
    $("#app").innerHTML = `<div class="empty"><h1>404</h1><p>Page not found.</p><a href="/">Back home</a></div>`;
  }

  async function postLoginNotices(user) {
    const key = `b1tm4p_login_notice_${user.id}`;
    const dismissed = localStorage.getItem(key);
    if (dismissed) return;
    const root = $("#modal-root");
    root.innerHTML = `<div class="modal-backdrop"><section class="modal">
      <h2>Before you continue</h2>
      <p><strong>Essential session cookie:</strong> B1tm4p uses its session cookie to keep you signed in. It is required for authentication and is not an optional analytics cookie.</p>
      <p><strong>Legal notice:</strong> User-submitted content is the responsibility of the user who submits it. The administrator/operator does not assume responsibility for user-submitted content.</p>
      <button class="primary" id="notice-dismiss">Continue</button>
    </section></div>`;
    $("#notice-dismiss").onclick = () => {
      localStorage.setItem(key, String(Date.now()));
      root.innerHTML = "";
    };
  }

  window.addEventListener("popstate", route);
  document.addEventListener("click", e => {
    const a = e.target.closest("a[href]");
    if (!a) return;
    const href = a.getAttribute("href");
    if (!href || href.startsWith("http") || href.startsWith("/admin-raw") || href === "/legal") return;
    if (href.startsWith("/")) { e.preventDefault(); navigate(href); }
  });

  renderFooter();
  route();
})();
