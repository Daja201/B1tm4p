# B1tm4p Content & Reports Slice

This archive contains the backend content/reports implementation specified by
the supplied B1tm4p API contract.

## Included

- separate `content.db` schema and initialization
- separate `reports.db` schema and initialization
- read-only lazy connections to `users.db` and `tags.db`
- posts, replies, nested reply tree, soft delete, likes
- multipart media handling with Sharp + multer
- public media serving integration
- report creation, listing, review
- LIKE-based title/body/tag/master search
- auth/role middleware compatible with the supplied contract
- nginx proxy snippet
- integration notes and curl verification examples

## Mounting

See `backend/index.content-service.example.js` for the intended integration
point in the existing backend process.

Do not merge the four SQLite files. Do not use SQLite ATTACH.
