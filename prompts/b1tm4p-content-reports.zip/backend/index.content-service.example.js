/*
  Integration point for the existing backend server.

  The core server already owns Express setup, cookie parsing, JSON parsing,
  CORS, and its auth middleware. Mount this slice as follows:

    const { initContentDb, initReportsDb } = require('./lib/contentDb');
    const { createContentRouter } = require('./routes/content');
    const { createReportsRouter } = require('./routes/reports');
    const { uploadErrorHandler } = require('./lib/uploads');

    const contentDb = initContentDb();
    const reportsDb = initReportsDb();

    app.use('/uploads/media', express.static('/data/uploads/media', {
      fallthrough: false,
      index: false,
      dotfiles: 'deny',
      maxAge: '1h'
    }));

    app.use('/api/v1', createContentRouter({ contentDb }));
    app.use('/api/v1', createReportsRouter({ contentDb, reportsDb }));

    // Keep this after the content/reports routers.
    app.use(uploadErrorHandler);

  The routes in this slice use the exact req.user shape documented by the
  supplied API contract and the b1tm4p_sid session cookie.
*/
