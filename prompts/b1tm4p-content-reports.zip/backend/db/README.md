# Database migrations

`schema_content.sql` and `schema_reports.sql` are idempotent boot-time schema
migrations. They must be executed against their own SQLite files only.
