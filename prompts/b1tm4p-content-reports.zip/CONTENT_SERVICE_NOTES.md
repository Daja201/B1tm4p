# B1tm4p Content & Reports Service Notes

## Contract status

Built against the supplied authoritative `API_CONTRACT.md`.

No changes are made to `users.db` or `tags.db`. The content service only reads
those databases.

The supplied contract specifies `req.user` as:

```js
{
  id,
  email,
  username,
  role,
  avatar_type,
  avatar_value,
  avatar_shape
}
```

The content service preserves that shape. `avatar_color` is additionally read
from `users.db` for public author rendering because the shared contract's
database schema defines that column.

## Authentication

The slice includes `backend/middleware/auth.js` as a drop-in equivalent for
the supplied contract in case the inherited core middleware is not directly
importable. The production integration should use the existing core middleware
if its module path differs.

The middleware:
- reads cookie `b1tm4p_sid`;
- SHA-256 hashes the raw token;
- looks up `sessions.token_hash` with `expires_at > current Unix seconds`;
- joins to `users`;
- attaches `req.user`;
- returns exactly `401 {"error":"unauthorized"}` for missing/invalid sessions.

Role middleware returns `403 {"error":"forbidden"}`.

## Separate SQLite connections

`content.db` and `reports.db` are opened by `backend/lib/contentDb.js`.

`users.db` and `tags.db` are opened separately, read-only, by
`backend/lib/crossDb.js`. There is no SQLite `ATTACH`, no cross-file foreign
key, and no cross-file SQL join.

Users/tags connections are lazy:
- if the file does not exist yet, the service returns no connection;
- the next request retries opening it;
- if the file's mtime changes, the old read connection is replaced;
- the connection uses `readonly: true` and `query_only = ON`.

This supports startup ordering where the core service has not created
`users.db` or `tags.db` yet.

The content/report databases are auto-created and schema-migrated on boot.

## Uploads

Post/reply uploads use multer memory storage so the service can validate the
declared body type and MIME before writing.

Accepted post/reply MIME types:
- image: image/jpeg, image/png, image/webp, image/gif
- sound: audio/mpeg, audio/wav, audio/ogg
- video: video/mp4, video/webm, video/quicktime

`UPLOAD_MAX_MB` controls the multer limit.

Images are decoded with Sharp, EXIF-rotated, resized to a maximum 1600px
longest dimension without enlargement, and encoded as WebP quality 84.
The resulting public path uses `/uploads/media/images/<uuid>.webp`.

Sound and video are stored byte-for-byte as received; there is intentionally
no transcoding. Transcoding is out of scope for this slice.

## Search

`GET /api/v1/posts?search=` uses SQLite `LOWER(... ) LIKE` against
`body_text` and `header_title`. It also searches tag/master-tag name and slug
through `tags.db`, then filters content posts by the resolved tag IDs.

FTS5 is intentionally not enabled in this slice. LIKE search keeps the schema
portable and avoids a second content-search index that would need its own
migration and synchronization rules. FTS5 is a documented stretch goal.

## Deleted replies

The recursive CTE fetches the complete reply tree in one content.db query.
Deleted replies are omitted unless they have a visible descendant. A deleted
reply with children is returned as a `[deleted]` placeholder with null body/file
data so the tree remains structurally intact.

## Nginx

`frontend/nginx/nginx.conf.snippet` proxies `/api/*` and `/uploads/*` to the
backend service. Merge these locations into the frontend nginx server block.

## End-to-end curl examples

Set:

```bash
BASE=http://localhost:8080
```

The examples assume an already-authenticated browser/session. For API clients,
preserve the `b1tm4p_sid` cookie received from the core login endpoint.

### 1. Login through the core service

```bash
curl -i -c cookies.txt \
  -H 'Content-Type: application/json' \
  -d '{"email":"alice@example.com","password":"minimum8"}' \
  "$BASE/api/v1/auth/login"
```

### 2. Post text

Replace `1` and `2` with an existing master tag ID and child tag ID from
`tags.db`.

```bash
curl -i -b cookies.txt \
  -F master_tag_id=1 \
  -F tag_id=2 \
  -F header_title='Hello B1tm4p' \
  -F body_text='First post from the content service.' \
  -F body_type=text \
  "$BASE/api/v1/posts"
```

### 3. Post an image

```bash
curl -i -b cookies.txt \
  -F master_tag_id=1 \
  -F tag_id=2 \
  -F header_title='An image' \
  -F body_text='Optional caption.' \
  -F body_type=image \
  -F file=@./example.jpg \
  "$BASE/api/v1/posts"
```

### 4. Reply to a post

If the response from step 2 contains `"id":10`:

```bash
curl -i -b cookies.txt \
  -F body_text='A direct reply.' \
  -F body_type=text \
  "$BASE/api/v1/posts/10/reply"
```

### 5. Nested reply-to-reply

If the direct reply has ID `25`:

```bash
curl -i -b cookies.txt \
  -F parent_reply_id=25 \
  -F body_text='A nested reply.' \
  -F body_type=text \
  "$BASE/api/v1/posts/10/reply"
```

### 6. Toggle a post like

```bash
curl -i -b cookies.txt \
  -X POST \
  "$BASE/api/v1/posts/10/like"
```

A second identical request toggles it off:

```bash
curl -i -b cookies.txt \
  -X POST \
  "$BASE/api/v1/posts/10/like"
```

The response is:

```json
{"liked":true,"likes_count":1}
```

or the corresponding false/count state.

### 7. Toggle a reply like

```bash
curl -i -b cookies.txt \
  -X POST \
  "$BASE/api/v1/replies/25/like"
```

### 8. Fetch the public post and full reply tree

```bash
curl -s "$BASE/api/v1/posts/10"
```

### 9. Search body/title/tag/master-tag

```bash
curl -sG \
  --data-urlencode 'search=photography' \
  --data-urlencode 'limit=20' \
  --data-urlencode 'offset=0' \
  "$BASE/api/v1/posts"
```

### 10. Filter by master/tag slug

```bash
curl -sG \
  --data-urlencode 'master_slug=photography' \
  --data-urlencode 'tag_slug=portraits' \
  "$BASE/api/v1/posts"
```

### 11. Report a post

```bash
curl -i -b cookies.txt \
  -H 'Content-Type: application/json' \
  -d '{"content_type":"post","content_id":10,"reason":"This content violates the community rules."}' \
  "$BASE/api/v1/reports"
```

### 12. List pending reports as manager/admin

```bash
curl -s -b manager-cookies.txt \
  "$BASE/api/v1/reports?status=pending&limit=20&offset=0"
```

### 13. Review a report

```bash
curl -i -b manager-cookies.txt \
  -X PATCH \
  -H 'Content-Type: application/json' \
  -d '{"status":"reviewed","review_note":"Reviewed by moderation."}' \
  "$BASE/api/v1/reports/1"
```

## Integration assumptions

1. The existing backend already has Express, cookie-parser, JSON parsing, and
   the core auth routes.
2. This slice is mounted under `/api/v1`.
3. The frontend nginx service can resolve the Compose hostname `backend`.
4. `/data` is the shared `b1tm4p_data` named volume.
5. `users.db` and `tags.db` use the exact schemas in the supplied contract.
6. `tags.db` contains the referenced master/tag rows before a post is created.
7. The inherited core app has no conflicting `/api/v1/posts` or
   `/api/v1/reports` handlers once this slice is installed; the reserved 501
   handlers must be removed/replaced by the core integration.
8. Error middleware should preserve the exact JSON error convention from the
   core app. The route code itself emits only machine-safe lowercase errors.
